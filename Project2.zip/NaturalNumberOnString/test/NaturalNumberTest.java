import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;

/**
 * JUnit test fixture for {@code NaturalNumber}'s constructors and kernel
 * methods.
 *
 * @author Xinwei Zhang and Hanqin Zhang
 *
 */
public abstract class NaturalNumberTest {

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @return the new number
     * @ensures constructorTest = 0
     */
    protected abstract NaturalNumber constructorTest();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorTest = i
     */
    protected abstract NaturalNumber constructorTest(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorTest)
     */
    protected abstract NaturalNumber constructorTest(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorTest = n
     */
    protected abstract NaturalNumber constructorTest(NaturalNumber n);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @return the new number
     * @ensures constructorRef = 0
     */
    protected abstract NaturalNumber constructorRef();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorRef = i
     */
    protected abstract NaturalNumber constructorRef(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorRef)
     */
    protected abstract NaturalNumber constructorRef(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorRef = n
     */
    protected abstract NaturalNumber constructorRef(NaturalNumber n);

    // TODO - add test cases for four constructors, multiplyBy10, divideBy10, isZero
    /**
     * Test for Default Constructor.
     */
    @Test
    public final void testDefaultConstructor() {
        NaturalNumber s = this.constructorTest();
        NaturalNumber r = this.constructorRef();
        assertEquals(s, r);
    }

    /**
     * Test for Int Constructor for 0.
     */
    @Test
    public final void testIntConstructorfor0() {
        NaturalNumber n = this.constructorTest(0);
        NaturalNumber r = this.constructorRef(0);
        assertEquals(n, r);
    }

    /**
     * Test for Int Constructor for 5.
     */
    @Test
    public final void testIntConstructorforSingleDigit() {
        NaturalNumber n = this.constructorTest(5);
        NaturalNumber r = this.constructorRef(5);
        assertEquals(n, r);
    }

    /**
     * Test for Int Constructor for 58.
     */
    @Test
    public final void testIntConstructorforTwoDigits() {
        NaturalNumber n = this.constructorTest(58);
        NaturalNumber r = this.constructorRef(58);
        assertEquals(n, r);
    }

    /**
     * Test for Int Constructor for 580.
     */
    @Test
    public final void testIntConstructorforThreeDigits() {
        NaturalNumber n = this.constructorTest(580);
        NaturalNumber r = this.constructorRef(580);
        assertEquals(n, r);
    }

    /**
     * Test for Int Constructor for 580.
     */
    @Test
    public final void testIntConstructorforIntegerMax() {
        NaturalNumber n = this.constructorTest(Integer.MAX_VALUE);
        NaturalNumber r = this.constructorRef(Integer.MAX_VALUE);
        assertEquals(n, r);
    }

    /**
     * Test for String Constructor for 0.
     */
    public final void testStringConstructorfor0() {
        NaturalNumber n = this.constructorTest("0");
        NaturalNumber r = this.constructorRef("0");
        assertEquals(n, r);
    }

    /**
     * Test for String Constructor for 2.
     */
    public final void testStringConstructorforSingleCharacter() {
        NaturalNumber n = this.constructorTest("2");
        NaturalNumber r = this.constructorRef("2");
        assertEquals(n, r);
    }

    /**
     * Test for String Constructor for 25.
     */
    public final void testStringConstructorforTwoCharacters() {
        NaturalNumber n = this.constructorTest("25");
        NaturalNumber r = this.constructorRef("25");
        assertEquals(n, r);
    }

    /**
     * Test for String Constructor for 260.
     */
    public final void testStringConstructorforThreeCharacters() {
        NaturalNumber n = this.constructorTest("260");
        NaturalNumber r = this.constructorRef("260");
        assertEquals(n, r);
    }

    /**
     * Test for Natural Number Constructor for 0.
     */
    public final void testNNConstructorfor0() {
        NaturalNumber r = this.constructorRef(0);
        NaturalNumber n = this.constructorTest(r);

        assertEquals(n, r);
    }

    /**
     * Test for Natural Number Constructor for 2.
     */
    public final void testNNConstructorforSingleDigits() {
        NaturalNumber Test = this.constructorTest(2);
        NaturalNumber n = this.constructorTest(Test);
        NaturalNumber r = this.constructorTest(Test);
        assertEquals(n, r);
    }

    /**
     * Test for Natural Number Constructor for 25.
     */
    public final void testNNConstructorforTwoDigits() {

        NaturalNumber Test = this.constructorTest(25);
        NaturalNumber n = this.constructorTest(Test);
        NaturalNumber r = this.constructorTest(Test);
        assertEquals(n, r);
    }

    /**
     * Test for Natural Number Constructor for 270.
     */
    public final void testNNConstructorforThreeDigits() {
        NaturalNumber Test = this.constructorTest(270);
        NaturalNumber n = this.constructorTest(Test);
        NaturalNumber r = this.constructorTest(Test);
        assertEquals(n, r);
    }

    /**
     * Test for multiplyBy10 on 0.
     */
    @Test
    public final void testMultiplyBy10on0() {
        NaturalNumber s = this.constructorTest();
        NaturalNumber r = this.constructorRef();
        r.multiplyBy10(0);
        s.multiplyBy10(0);
        assertEquals(s, r);
    }

    /**
     * Test for multiplyBy10 on 0 and add 5 to this.
     */
    @Test
    public final void testMultiplyBy10on0AddSingleDigit() {
        NaturalNumber s = this.constructorTest();
        NaturalNumber r = this.constructorRef();
        r.multiplyBy10(5);
        s.multiplyBy10(5);
        assertEquals(s, r);
    }

    /**
     * Test for multiplyBy10 on single digit number.
     */
    @Test
    public final void testMultiplyBy10onOneDigitNumber() {
        NaturalNumber s = this.constructorTest(7);
        NaturalNumber r = this.constructorRef(7);
        s.multiplyBy10(0);
        r.multiplyBy10(0);
        assertEquals(s, r);
    }

    /**
     * Test for multiplyBy10 on single digit number and add 5 to this.
     */
    @Test
    public final void testMultiplyBy10onOneDigitNumberAddSingleDigit() {
        NaturalNumber s = this.constructorTest(7);
        NaturalNumber r = this.constructorRef(7);
        s.multiplyBy10(5);
        r.multiplyBy10(5);
        assertEquals(s, r);
    }

    /**
     * Test for multiplyBy10 on two digit number
     */
    @Test
    public final void testMultiplyBy10onTwoDigitNumber() {
        NaturalNumber s = this.constructorTest(75);
        NaturalNumber r = this.constructorRef(75);
        s.multiplyBy10(0);
        r.multiplyBy10(0);
        assertEquals(s, r);
    }

    /**
     * Test for multiplyBy10 on two digit number and add 5 to this.
     */
    @Test
    public final void testMultiplyBy10onTwoDigitNumberAddSigleDigit() {
        NaturalNumber s = this.constructorTest(75);
        NaturalNumber r = this.constructorRef(75);
        s.multiplyBy10(5);
        r.multiplyBy10(5);
        assertEquals(s, r);
    }

    /**
     * Test for multiplyBy10 on three digit number
     */
    @Test
    public final void testMultiplyBy10onThreeDigitNumber() {
        NaturalNumber s = this.constructorTest(750);
        NaturalNumber r = this.constructorRef(750);
        s.multiplyBy10(0);
        r.multiplyBy10(0);
        assertEquals(s, r);
    }

    /**
     * Test for multiplyBy10 on three digit number and add 5 to this
     */
    @Test
    public final void testMultiplyBy10onThreeDigitNumberAddSingleDigit() {
        NaturalNumber s = this.constructorTest(750);
        NaturalNumber r = this.constructorRef(750);
        s.multiplyBy10(5);
        r.multiplyBy10(5);
        assertEquals(s, r);
    }

    /**
     * Test for multiplyBy10 on max integer
     */
    @Test
    public final void testMultiplyBy10onMaxInteger() {
        NaturalNumber s = this.constructorTest(Integer.MAX_VALUE);
        NaturalNumber r = this.constructorRef(Integer.MAX_VALUE);
        s.multiplyBy10(0);
        r.multiplyBy10(0);
        assertEquals(s, r);
    }

    /**
     * Test for multiplyBy10 on max integer and add 5 to this
     */
    @Test
    public final void testMultiplyBy10onMaxIntegerAddSingleDigit() {
        NaturalNumber s = this.constructorTest(Integer.MAX_VALUE);
        NaturalNumber r = this.constructorRef(Integer.MAX_VALUE);
        s.multiplyBy10(5);
        r.multiplyBy10(5);
        assertEquals(s, r);
    }

    /**
     * Test for divideBy10 on 0.
     */
    @Test
    public final void testDivideBy10on0() {
        NaturalNumber s = this.constructorTest();
        NaturalNumber r = this.constructorRef();
        int remainder = 0;
        remainder = s.divideBy10();
        int temp = r.divideBy10();
        assertEquals(s, r);
        assertEquals(remainder, temp);
    }

    /**
     * /** Test for divideBy10 on single digit number.
     */
    @Test
    public final void testDivideBy10onSingleDigitNumber() {
        NaturalNumber s = this.constructorTest(7);
        NaturalNumber r = this.constructorTest(7);
        int remainder;
        remainder = s.divideBy10();
        int temp = r.divideBy10();
        assertEquals(s, r);
        assertEquals(remainder, temp);
    }

    /**
     * /** Test for divideBy10 on two digit number.
     */
    @Test
    public final void testDivideBy10onTwoDigitNumber() {
        NaturalNumber s = this.constructorTest(70);
        NaturalNumber r = this.constructorTest(70);
        int remainder;
        remainder = s.divideBy10();
        int temp = r.divideBy10();
        assertEquals(s, r);
        assertEquals(remainder, temp);
    }

    /**
     * /** Test for divideBy10 on two digit number.
     */
    @Test
    public final void testDivideBy10onTwoDigitNumber2() {
        NaturalNumber s = this.constructorTest(76);
        NaturalNumber r = this.constructorTest(76);
        int remainder;
        remainder = s.divideBy10();
        int temp = r.divideBy10();
        assertEquals(s, r);
        assertEquals(remainder, temp);
    }

    /**
     * /** Test for divideBy10 on three digit number.
     */
    @Test
    public final void testDivideBy10onThreeDigitNumber() {
        NaturalNumber s = this.constructorTest(760);
        NaturalNumber r = this.constructorTest(760);
        int remainder;
        remainder = s.divideBy10();
        int temp = r.divideBy10();
        assertEquals(s, r);
        assertEquals(remainder, temp);
    }

    /**
     * /** Test for divideBy10 on three digit number.
     */
    @Test
    public final void testDivideBy10onThreeDigitNumber2() {
        NaturalNumber s = this.constructorTest(766);
        NaturalNumber r = this.constructorTest(766);
        int remainder;
        remainder = s.divideBy10();
        int temp = r.divideBy10();
        assertEquals(s, r);
        assertEquals(remainder, temp);
    }

    /**
     * /** Test for divideBy10 on max integer.
     */
    @Test
    public final void testDivideBy10onMxInteger() {
        NaturalNumber s = this.constructorTest(Integer.MAX_VALUE);
        NaturalNumber r = this.constructorTest(Integer.MAX_VALUE);
        int remainder;
        remainder = s.divideBy10();
        int temp = r.divideBy10();
        assertEquals(s, r);
        assertEquals(remainder, temp);
    }

    /**
     * /** Test for isZero on DefaultConstructor.
     */
    @Test
    public final void testIszerowithDefaultConstructor() {
        NaturalNumber s = this.constructorTest();
        NaturalNumber r = this.constructorTest();
        boolean a = s.isZero();
        boolean b = r.isZero();
        assertEquals(a, b);
    }

    /**
     * /** Test for isZero on Int Constructor.
     */
    @Test
    public final void testIszerowithIntConstructor() {
        NaturalNumber s = this.constructorTest(0);
        NaturalNumber r = this.constructorTest(0);
        boolean a = s.isZero();
        boolean b = r.isZero();
        assertEquals(a, b);
    }

    /**
     * /** Test for isZero on String Constructor.
     */
    @Test
    public final void testIszerowithStringConstructor() {
        NaturalNumber s = this.constructorTest("0");
        NaturalNumber r = this.constructorTest("0");
        boolean a = s.isZero();
        boolean b = r.isZero();
        assertEquals(a, b);
    }

    /**
     * /** Test for isZero on NN Constructor.
     */
    @Test
    public final void testIszerowithNNConstructor() {
        NaturalNumber Test = this.constructorTest();
        NaturalNumber s = this.constructorTest(Test);
        NaturalNumber r = this.constructorTest(Test);
        boolean a = s.isZero();
        boolean b = r.isZero();
        assertEquals(a, b);
    }

}
