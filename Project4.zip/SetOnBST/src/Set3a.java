import java.util.Iterator;

import components.binarytree.BinaryTree;
import components.binarytree.BinaryTree1;
import components.set.Set;
import components.set.SetSecondary;

/**
 * {@code Set} represented as a {@code BinaryTree} (maintained as a binary
 * search tree) of elements with implementations of primary methods.
 *
 * @param <T>
 *            type of {@code Set} elements
 * @mathdefinitions <pre>
 * IS_BST(
 *   tree: binary tree of T
 *  ): boolean satisfies
 *  [tree satisfies the binary search tree properties as described in the
 *   slides with the ordering reported by compareTo for T, including that
 *   it has no duplicate labels]
 * </pre>
 * @convention IS_BST($this.tree)
 * @correspondence this = labels($this.tree)
 *
 * @author Xinwei Zhang and Hanqin Zhang
 *
 */
public class Set3a<T extends Comparable<T>> extends SetSecondary<T> {

    /*
     * Private members --------------------------------------------------------
     */

    /**
     * Elements included in {@code this}.
     */
    private BinaryTree<T> tree;

    /**
     * Returns whether {@code x} is in {@code t}.
     *
     * @param <T>
     *            type of {@code BinaryTree} labels
     * @param t
     *            the {@code BinaryTree} to be searched
     * @param x
     *            the label to be searched for
     * @return true if t contains x, false otherwise
     * @requires IS_BST(t)
     * @ensures isInTree = (x is in labels(t))
     */
    private static <T extends Comparable<T>> boolean isInTree(BinaryTree<T> t,
            T x) {
        assert t != null : "Violation of: t is not null";
        assert x != null : "Violation of: x is not null";
        // 'hasornot' will be used to indicate whether the element 'x' is found
        boolean hasornot = false;
        // A for-each loop that iterates over each node in the binary tree 't'.
        for (T node : t) {
            // Check if the current node is equal to the element 'x'
            if (node.equals(x)) {
                //if equal, set hasornot as true
                hasornot = true;
            }
        }
        return hasornot;
    }

    /**
     * Inserts {@code x} in {@code t}.
     *
     * @param <T>
     *            type of {@code BinaryTree} labels
     * @param t
     *            the {@code BinaryTree} to be searched
     * @param x
     *            the label to be inserted
     * @aliases reference {@code x}
     * @updates t
     * @requires IS_BST(t) and x is not in labels(t)
     * @ensures IS_BST(t) and labels(t) = labels(#t) union {x}
     */
    private static <T extends Comparable<T>> void insertInTree(BinaryTree<T> t,
            T x) {
        assert t != null : "Violation of: t is not null";
        assert x != null : "Violation of: x is not null";
        // Create a new empty binary tree for the left subtree
        BinaryTree<T> left = new BinaryTree1<>();
        // Create a new empty binary tree for the right subtree
        BinaryTree<T> right = new BinaryTree1<>();
        // Check if the binary tree 't' is empty
        if (t.size() == 0) {
            // If 't' is empty, assemble 't' with 'x' as its root
            t.assemble(x, left, right);
        } else {
            // If 't' is not empty, disassemble 't'
            T root = t.disassemble(left, right);
            // Compare 'x' with the root of 't'
            if (x.compareTo(root) < 0) {
                // If 'x' < root, recursively search the left subtree
                insertInTree(left, x);
            } else {
                // If 'x' > root, recursively search the right subtree
                insertInTree(right, x);
            }
            // Reassemble 't' with its original root
            t.assemble(root, left, right);

        }

    }

    /**
     * Removes and returns the smallest (left-most) label in {@code t}.
     *
     * @param <T>
     *            type of {@code BinaryTree} labels
     * @param t
     *            the {@code BinaryTree} from which to remove the label
     * @return the smallest label in the given {@code BinaryTree}
     * @updates t
     * @requires IS_BST(t) and |t| > 0
     * @ensures <pre>
     * IS_BST(t)  and  removeSmallest = [the smallest label in #t]  and
     *  labels(t) = labels(#t) \ {removeSmallest}
     * </pre>
     */
    private static <T> T removeSmallest(BinaryTree<T> t) {
        assert t != null : "Violation of: t is not null";
        assert t.size() > 0 : "Violation of: |t| > 0";
        // Create a new empty binary tree for the left subtree
        BinaryTree<T> left = new BinaryTree1<>();
        // Create a new empty binary tree for the right subtree
        BinaryTree<T> right = new BinaryTree1<>();
        // Disassemble 't' to get its root and its left and right subtrees
        T root = t.disassemble(left, right);
        // Initialize 'result' with the root value
        T result = root;
        // Check if the left subtree is empty
        if (left.size() == 0) {
            // If the left subtree is empty, the current root is the smallest element
            result = root;
            // Transfer all elements from the right subtree to 't'
            t.transferFrom(right);
        } else {
            // If the left subtree is not empty
            //recursively find and remove the smallest element from the left subtree
            result = removeSmallest(left);
            // Reassemble 't'
            t.assemble(root, left, right);

        }
        return result;
    }

    /**
     * Finds label {@code x} in {@code t}, removes it from {@code t}, and
     * returns it.
     *
     * @param <T>
     *            type of {@code BinaryTree} labels
     * @param t
     *            the {@code BinaryTree} from which to remove label {@code x}
     * @param x
     *            the label to be removed
     * @return the removed label
     * @updates t
     * @requires IS_BST(t) and x is in labels(t)
     * @ensures <pre>
     * IS_BST(t)  and  removeFromTree = x  and
     *  labels(t) = labels(#t) \ {x}
     * </pre>
     */
    private static <T extends Comparable<T>> T removeFromTree(BinaryTree<T> t,
            T x) {
        assert t != null : "Violation of: t is not null";
        assert x != null : "Violation of: x is not null";
        assert t.size() > 0 : "Violation of: x is in labels(t)";
        // Create a new empty binary tree for the left subtree
        BinaryTree<T> left = new BinaryTree1<>();
        // Create a new empty binary tree for the right subtree
        BinaryTree<T> right = new BinaryTree1<>();
        // Disassemble 't'
        T root = t.disassemble(left, right);
        // Initialize 'newroot' with the current root value
        T newroot = root;
        // Check if the root of 't' is the element to be removed
        if (x.equals(root)) {
            // If the root needs to be removed and the right subtree is not empty
            if (right.size() > 0) {
                // Find and remove the smallest element from the right subtree
                newroot = removeSmallest(right);
                // Reassemble 't' with the new root (smallest from right subtree)
                t.assemble(newroot, left, right);

            } else {
                // If the right subtree is empty, transfer the left subtree to 't'
                t.transferFrom(left);
            }
        } else {
            // If the root is not the element to be removed
            if (x.compareTo(root) < 0) {
                // If 'x'<root recursively remove 'x' from the left subtree
                root = removeFromTree(left, x);
                //reassemble 't' with origin root of t
                t.assemble(newroot, left, right);
            } else {
                // If 'x'>root recursively remove 'x' from the right subtree
                root = removeFromTree(right, x);
                //reassemble 't' with origin root of t
                t.assemble(newroot, left, right);
            }
        }

        return root;
    }

    /**
     * Creator of initial representation.
     */
    private void createNewRep() {

        this.tree = new BinaryTree1<T>();

    }

    /*
     * Constructors -----------------------------------------------------------
     */

    /**
     * No-argument constructor.
     */
    public Set3a() {

        this.createNewRep();

    }

    /*
     * Standard methods -------------------------------------------------------
     */

    @SuppressWarnings("unchecked")
    @Override
    public final Set<T> newInstance() {
        try {
            return this.getClass().getConstructor().newInstance();
        } catch (ReflectiveOperationException e) {
            throw new AssertionError(
                    "Cannot construct object of type " + this.getClass());
        }
    }

    @Override
    public final void clear() {
        this.createNewRep();
    }

    @Override
    public final void transferFrom(Set<T> source) {
        assert source != null : "Violation of: source is not null";
        assert source != this : "Violation of: source is not this";
        assert source instanceof Set3a<?> : ""
                + "Violation of: source is of dynamic type Set3<?>";
        /*
         * This cast cannot fail since the assert above would have stopped
         * execution in that case: source must be of dynamic type Set3a<?>, and
         * the ? must be T or the call would not have compiled.
         */
        Set3a<T> localSource = (Set3a<T>) source;
        this.tree = localSource.tree;
        localSource.createNewRep();
    }

    /*
     * Kernel methods ---------------------------------------------------------
     */

    @Override
    public final void add(T x) {
        assert x != null : "Violation of: x is not null";
        assert !this.contains(x) : "Violation of: x is not in this";
        // Create a new empty binary tree for the left subtree
        BinaryTree<T> left = new BinaryTree1<>();
        // Create a new empty binary tree for the right subtree
        BinaryTree<T> right = new BinaryTree1<>();
        //check this.tree is empty or not
        if (this.tree.size() == 0) {
            //if it's empty, assemble 't' with x
            this.tree.assemble(x, left, right);
        } else {
            //else insert x into BST
            insertInTree(this.tree, x);

        }

    }

    @Override
    public final T remove(T x) {
        assert x != null : "Violation of: x is not null";
        assert this.contains(x) : "Violation of: x is in this";
        //remove x from BST
        return removeFromTree(this.tree, x);
    }

    @Override
    public final T removeAny() {
        assert this.size() > 0 : "Violation of: this /= empty_set";
        //remove any element from BST
        return removeSmallest(this.tree);
    }

    @Override
    public final boolean contains(T x) {
        assert x != null : "Violation of: x is not null";
        //check if x is in BST or not
        return isInTree(this.tree, x);
    }

    @Override
    public final int size() {
        //return this.tree's size
        return this.tree.size();
    }

    @Override
    public final Iterator<T> iterator() {
        return this.tree.iterator();
    }

}
