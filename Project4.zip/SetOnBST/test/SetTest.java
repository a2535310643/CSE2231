import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;

/**
 * JUnit test fixture for {@code Set<String>}'s constructor and kernel methods.
 *
 * @author Xinwei Zhang and Hanqin Zhang
 *
 */
public abstract class SetTest {

    /**
     * Invokes the appropriate {@code Set} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new set
     * @ensures constructorTest = {}
     */
    protected abstract Set<String> constructorTest();

    /**
     * Invokes the appropriate {@code Set} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new set
     * @ensures constructorRef = {}
     */
    protected abstract Set<String> constructorRef();

    /**
     * Creates and returns a {@code Set<String>} of the implementation under
     * test type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsTest = [entries in args]
     */
    private Set<String> createFromArgsTest(String... args) {
        Set<String> set = this.constructorTest();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    /**
     * Creates and returns a {@code Set<String>} of the reference implementation
     * type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsRef = [entries in args]
     */
    private Set<String> createFromArgsRef(String... args) {
        Set<String> set = this.constructorRef();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    /**
     * Test case for Default Constructor.
     */
    @Test
    public final void testDefaultConstructor() {
        Set<String> s = this.createFromArgsTest();
        Set<String> sExpected = this.createFromArgsRef();
        assertEquals(s, sExpected);
    }

    /**
     * Test case for Constructor.
     */
    @Test
    public final void testArgsConstructor() {
        Set<String> s = this.createFromArgsTest("1", "2", "3");
        Set<String> sExpected = this.createFromArgsRef("1", "2", "3");
        assertEquals(s, sExpected);
    }

    /**
     * Test case for add.
     */
    @Test
    public final void testAddtoEmpty() {
        Set<String> s = this.createFromArgsTest();
        Set<String> sExpected = this.constructorRef();
        s.add("2");
        sExpected.add("2");
        assertEquals(s, sExpected);
    }

    /**
     * Test case for add.
     */
    @Test
    public final void testAddtoNonEmpty1() {
        Set<String> s = this.createFromArgsTest("2");
        Set<String> sExpected = this.createFromArgsRef("2");
        s.add("3");
        sExpected.add("3");
        assertEquals(s, sExpected);
    }

    /**
     * Test case for add.
     */
    @Test
    public final void testAddtowithtwoelements1() {
        Set<String> s = this.createFromArgsTest("2", "3");
        Set<String> sExpected = this.createFromArgsRef("2", "3");
        s.add("1");
        sExpected.add("1");
        assertEquals(s, sExpected);
    }

    /**
     * Test case for add.
     */
    @Test
    public final void testAddtowithtwoelements2() {
        Set<String> s = this.createFromArgsTest("2", "3");
        Set<String> sExpected = this.createFromArgsRef("2", "3");
        s.add("4");
        sExpected.add("4");
        assertEquals(s, sExpected);
    }

    /**
     * Test case for add.
     */
    @Test
    public final void testAddtowithThreelements1() {
        Set<String> s = this.createFromArgsTest("2", "3", "0");
        Set<String> sExpected = this.createFromArgsRef("2", "3", "0");
        s.add("1");
        sExpected.add("1");
        assertEquals(s, sExpected);
    }

    /**
     * Test case for add.
     */
    @Test
    public final void testAddtowithThreelements2() {
        Set<String> s = this.createFromArgsTest("2", "1", "4");
        Set<String> sExpected = this.createFromArgsRef("2", "1", "4");
        s.add("3");
        sExpected.add("3");
        assertEquals(s, sExpected);
    }

    /**
     * Test case for remove.
     */
    @Test
    public final void testremovewithoneelement() {
        Set<String> s = this.createFromArgsTest("2");
        Set<String> sExpected = this.createFromArgsRef("2");
        s.remove("2");
        sExpected.remove("2");
        assertEquals(s, sExpected);
    }

    /**
     * Test case for remove.
     */
    @Test
    public final void testremovewithtwoelement1() {
        Set<String> s = this.createFromArgsTest("2", "1");
        Set<String> sExpected = this.createFromArgsRef("2", "1");
        s.remove("2");
        sExpected.remove("2");
        assertEquals(s, sExpected);
    }

    /**
     * Test case for remove.
     */
    @Test
    public final void testremovewithtwoelement2() {
        Set<String> s = this.createFromArgsTest("2", "1");
        Set<String> sExpected = this.createFromArgsRef("2", "1");
        s.remove("1");
        sExpected.remove("1");
        assertEquals(s, sExpected);
    }

    /**
     * Test case for remove.
     */
    @Test
    public final void testremovewiththreeelement1() {
        Set<String> s = this.createFromArgsTest("2", "1", "3");
        Set<String> sExpected = this.createFromArgsRef("2", "1", "3");
        s.remove("2");
        sExpected.remove("2");
        assertEquals(s, sExpected);
    }

    /**
     * Test case for remove.
     */
    @Test
    public final void testremovewiththreeelement2() {
        Set<String> s = this.createFromArgsTest("2", "1", "3");
        Set<String> sExpected = this.createFromArgsRef("2", "1", "3");
        s.remove("1");
        sExpected.remove("1");
        assertEquals(s, sExpected);
    }

    /**
     * Test case for remove.
     */
    @Test
    public final void testremovewiththreeelement3() {
        Set<String> s = this.createFromArgsTest("2", "1", "3");
        Set<String> sExpected = this.createFromArgsRef("2", "1", "3");
        s.remove("3");
        sExpected.remove("3");
        assertEquals(s, sExpected);
    }

    /**
     * Test case for size.
     */
    @Test
    public final void testsizewithonelement() {
        Set<String> s = this.createFromArgsTest("2");
        assertEquals(s.size(), 1);
    }

    /**
     * Test case for size.
     */
    @Test
    public final void testsizewithtwolement2() {
        Set<String> s = this.createFromArgsTest("2", "1");
        assertEquals(s.size(), 2);
    }

    /**
     * Test case for size.
     */
    @Test
    public final void testsizewiththreeelement() {
        Set<String> s = this.createFromArgsTest("2", "1", "3");
        assertEquals(s.size(), 3);
    }

    /**
     * Test case for removeAny.
     */
    @Test
    public final void testremoveanywithonelement() {
        Set<String> s = this.createFromArgsTest("2");
        int size = s.size();
        s.removeAny();
        assertEquals(size - 1, s.size());
    }

    /**
     * Test case for removeAny.
     */
    @Test
    public final void testremoveanywithtwolement() {
        Set<String> s = this.createFromArgsTest("2", "3");
        int size = s.size();
        s.removeAny();
        assertEquals(size - 1, s.size());
    }

    /**
     * Test case for removeAny.
     */
    @Test
    public final void testremoveanywiththreelement() {
        Set<String> s = this.createFromArgsTest("2", "3", "4");
        int size = s.size();
        s.removeAny();
        assertEquals(size - 1, s.size());
    }

    /**
     * Test case for contains.
     */
    @Test
    public final void testcontainsywithonelement() {
        Set<String> s = this.createFromArgsTest("2");

        assertEquals(s.contains("2"), true);
        assertEquals(s.contains("3"), false);
        assertEquals(s.contains("4"), false);
        assertEquals(s.contains("5"), false);
        assertEquals(s.contains("1"), false);
    }

    /**
     * Test case for contains.
     */
    @Test
    public final void testcontainsywithtwolement() {
        Set<String> s = this.createFromArgsTest("2", "3");

        assertEquals(s.contains("2"), true);
        assertEquals(s.contains("3"), true);
        assertEquals(s.contains("4"), false);
        assertEquals(s.contains("5"), false);
        assertEquals(s.contains("1"), false);
    }

    /**
     * Test case for contains.
     */
    @Test
    public final void testcontainsywiththreelement() {
        Set<String> s = this.createFromArgsTest("2", "3", "4");

        assertEquals(s.contains("2"), true);
        assertEquals(s.contains("3"), true);
        assertEquals(s.contains("4"), true);
        assertEquals(s.contains("5"), false);
        assertEquals(s.contains("6"), false);
        assertEquals(s.contains("1"), false);
    }

}
