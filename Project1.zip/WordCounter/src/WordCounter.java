import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Simple HelloWorld program (clear of Checkstyle and SpotBugs warnings).
 *
 * @author Xinwei Zhang
 */
public final class WordCounter {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private WordCounter() {
        // no code needed here
    }

    /**
     * Compare {@code String}s in lexicographic order, also ignoring capital
     * letters.
     */
    private static class Abcd implements Comparator<String> {
        @Override
        public int compare(String a, String b) {
            //use toLowerCase so case is ignored
            //order the list as abcd..z
            return a.toLowerCase().compareTo(b.toLowerCase());
        }
    }

    /**
     * Extracts and returns the next word from a given position in a string,
     * using a set of specified separators.
     *
     * This method iterates through the characters of the string starting from
     * the specified position. It builds a word by concatenating characters
     * until it encounters one of the specified separators. When a separator is
     * encountered, the method stops adding characters to the word and returns
     * the word.
     *
     * @param text
     *            The string from which to extract the word.
     * @param position
     *            The starting index in the string from which to begin the
     *            extraction.
     * @param separators
     *            A set of characters that are considered as word separators.
     * @return A String representing the next word in the text starting from the
     *         given position. If no word is found, returns an empty string.
     */
    public static String nextWordSeparator(String text, int position,
            Set<Character> separators) {
        // Initialize an empty string to build the next word.
        String s = "";
        // Flag to indicate when a separator is encountered.
        boolean next = false;
        char a;
        // Iterate through the string starting from the given position
        for (int i = position; i < text.length() && !next; i++) {
            // Get the current character.
            a = text.charAt(i);
            if (!separators.contains(a)) {
                // If the current character is not a separator, add it to the word.
                s += a;
            } else if (separators.contains(a)) {
                // If the current character is a separator,
                //set the flag to true to end the loop.
                next = true;
            }
        }
        // Return the constructed word.
        return s;
    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param charset
     *            the {@code Set} to be replaced
     * @replaces charSet
     * @ensures charSet = entries(str)
     */
    private static void generateElements(String str, Set<Character> charset) {
        assert str != null : "Violation of: str is not null";
        assert charset != null : "Violation of: charSet is not null";
        // Clear the charset to ensure it starts empty.
        charset.clear();
        // Initialize a counter to iterate through the string.
        int i = 0;
        // Iterate over each character in the string.
        while (i < str.length()) {
            // If the current character is not already in the charset, add it.
            if (!charset.contains(str.charAt(i))) {
                charset.add(str.charAt(i));
            }
            // Move to the next character.
            i++;
        }

    }

    /**
     * Creates a map from the words in the text file
     *
     * @param file
     *            the input text file
     * @param counter
     *            an empty map that will have all of the words and the number of
     *            words
     *
     * @updates counter
     *
     * @ensures <pre>
     * file's words = counter's keys
     * </pre>
     */
    public static void createVoc(SimpleReader file,
            Map<String, Integer> counter) {
        int position = 0;
        // Initialize a set to store special characters considered as separators.
        Set<Character> specialChars = new Set1L<Character>();
        //Characters that are considering separators
        String chars = " \t~`!@#$%^&*()-_+={}[]|;:'<>,.?/";
        //create a set of the separator characters
        generateElements(chars, specialChars);
        // Read through the file until the end of stream is reached.
        while (!file.atEOS()) {
            String line = file.nextLine();
            //reset position on line for each line
            position = 0;
            // Process each line character by character.
            while (position < line.length()) {
                // Extract the next word or separator.
                String wordOrSep = nextWordSeparator(line, position,
                        specialChars);
                // If the extracted string is a word, process it.
                if (wordOrSep.length() > 0) {
                    // If the word is not already in the map, add it with count 1.
                    if (!counter.hasKey(wordOrSep)) {
                        counter.add(wordOrSep, 1);
                    } else {
                        // If the word is already in the map, increment its count.
                        int num = counter.value(wordOrSep);
                        num++;
                        //now replace the value that was associated before
                        counter.replaceValue(wordOrSep, num);
                    }
                }
                position = position + wordOrSep.length() + 1;
            }

        }
    }

    /**
     * Extracts terms from the Map and converts them into a sorted Queue.
     *
     * @param voc
     *            the given Map that stores all terms with definition
     * @return A sorted Queue<String> that stores all terms
     */
    public static Queue<String> mapToSortedQueue(Map<String, Integer> voc) {
        // Create a new Queue to hold the sorted words.
        Queue<String> sortedQueue = new Queue1L<String>();
        // Iterate over the Map and enqueue each word into the Queue.
        for (Map.Pair<String, Integer> word : voc) {
            sortedQueue.enqueue(word.key());
        }
        // Create a Comparator to define the sorting order.
        Comparator<String> strCompare = new Abcd();
        // Sort the Queue using the created Comparator.
        sortedQueue.sort(strCompare);
        // Return the sorted Queue.
        return sortedQueue;
    }

    /**
     * Creates an HTML page with a table based on the map as a parameter.
     *
     * @param output
     *            the file this is being output to
     *
     * @param voc
     *            the map that has all the words and counts
     *
     * @param sorted
     *            the Queue that has all of the words in alphabetical order
     * @param input
     *            the text file input
     * @clears sorted
     * @ensures <pre>
     * {HTML table elements = m}
     * </pre>
     *
     */

    public static void createTable(SimpleWriter output, SimpleReader input,
            Map<String, Integer> voc, Queue<String> sorted) {
        assert voc != null : "Violation of: m is not null";
        // Start writing the HTML structure to the output.
        output.println("<html>");
        output.println("<head>");
        // Set the title of the HTML document.
        output.println("<title>Words Counted in " + input.name() + "</title>");
        output.println("<body>");
        // Heading for the HTML page.
        output.println("<h2>Words Counted in " + input.name() + "</h2>");
        output.println("<hr />");
        //now create the table
        output.println("<table border=\"1\">");
        output.println("<tr>");
        output.println("<th>Words</th>");
        output.println("<th>Counts</th>");
        output.println("</tr>");
        //Loops through the Map, writing out the Keys and its respective Values
        while (sorted.length() > 0) {
            // Dequeue the word from the sorted Queue.
            String word = sorted.dequeue();
            // Retrieve the count of the word from the Map.
            int count = voc.value(word);
            // Write the word and its count as a row in the table.
            output.println("<tr>");
            output.println("<td>" + word + "</td>");
            output.println("<td>" + count + "</td>");
            output.println("</tr>");
        }
        // End the table and the HTML structure.
        output.println("</table>");
        output.println("</body>");
        output.println("</html>");

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        SimpleWriter out = new SimpleWriter1L();
        SimpleReader in = new SimpleReader1L();
        out.print("Please enter your txt file:");
        String fileName = in.nextLine();
        out.print("Please enter your folder:");
        String filePath = in.nextLine();
        SimpleReader fileReader = new SimpleReader1L(fileName);
        SimpleWriter output = new SimpleWriter1L(filePath);
        Map<String, Integer> counter = new Map1L<String, Integer>();
        createVoc(fileReader, counter);
        Queue<String> sortedQueue = mapToSortedQueue(counter);
        createTable(output, fileReader, counter, sortedQueue);
        in.close();
        out.close();
        fileReader.close();
        output.close();
    }

}
