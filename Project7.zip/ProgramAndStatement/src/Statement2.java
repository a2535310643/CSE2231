import components.sequence.Sequence;
import components.statement.Statement;
import components.statement.StatementSecondary;
import components.tree.Tree;
import components.tree.Tree1;
import components.utilities.Tokenizer;

/**
 * {@code Statement} represented as a {@code Tree<StatementLabel>} with
 * implementations of primary methods.
 *
 * @convention [$this.rep is a valid representation of a Statement]
 * @correspondence this = $this.rep
 *
 * @author Xinwei Zhang and Hanqin Zhang
 *
 */
public class Statement2 extends StatementSecondary {

    /*
     * Private members --------------------------------------------------------
     */

    /**
     * Label class for the tree representation.
     */
    private static final class StatementLabel {

        /**
         * Statement kind.
         */
        private Kind kind;

        /**
         * IF/IF_ELSE/WHILE statement condition.
         */
        private Condition condition;

        /**
         * CALL instruction name.
         */
        private String instruction;

        /**
         * Constructor for BLOCK.
         *
         * @param k
         *            the kind of statement
         *
         * @requires k = BLOCK
         * @ensures this = (BLOCK, ?, ?)
         */
        private StatementLabel(Kind k) {
            assert k == Kind.BLOCK : "Violation of: k = BLOCK";
            this.kind = k;
        }

        /**
         * Constructor for IF, IF_ELSE, WHILE.
         *
         * @param k
         *            the kind of statement
         * @param c
         *            the statement condition
         *
         * @requires k = IF or k = IF_ELSE or k = WHILE
         * @ensures this = (k, c, ?)
         */
        private StatementLabel(Kind k, Condition c) {
            assert k == Kind.IF || k == Kind.IF_ELSE || k == Kind.WHILE : ""
                    + "Violation of: k = IF or k = IF_ELSE or k = WHILE";
            this.kind = k;
            this.condition = c;
        }

        /**
         * Constructor for CALL.
         *
         * @param k
         *            the kind of statement
         * @param i
         *            the instruction name
         *
         * @requires k = CALL and [i is an IDENTIFIER]
         * @ensures this = (CALL, ?, i)
         */
        private StatementLabel(Kind k, String i) {
            assert k == Kind.CALL : "Violation of: k = CALL";
            assert i != null : "Violation of: i is not null";
            assert Tokenizer
                    .isIdentifier(i) : "Violation of: i is an IDENTIFIER";
            this.kind = k;
            this.instruction = i;
        }

        @Override
        public String toString() {
            String condition = "?", instruction = "?";
            if ((this.kind == Kind.IF) || (this.kind == Kind.IF_ELSE)
                    || (this.kind == Kind.WHILE)) {
                condition = this.condition.toString();
            } else if (this.kind == Kind.CALL) {
                instruction = this.instruction;
            }
            return "(" + this.kind + "," + condition + "," + instruction + ")";
        }

    }

    /**
     * The tree representation field.
     */
    private Tree<StatementLabel> rep;

    /**
     * Creator of initial representation.
     */
   private void createNewRep() {
        // Create a new Tree1 instance to represent the program
        this.rep = new Tree1<StatementLabel>();
        // Create a new sequence of Tree nodes to store children of the root node
        Sequence<Tree<StatementLabel>> children = this.rep.newSequenceOfTree();
        // Create a root node of type BLOCK
        StatementLabel root = new StatementLabel(Kind.BLOCK);
        // Assemble the root node with the empty sequence of children
        this.rep.assemble(root, children);
    }







    /*
     * Constructors -----------------------------------------------------------
     */

    /**
     * No-argument constructor.
     */
    public Statement2() {
        this.rep = new Tree1<StatementLabel>();
        Sequence<Tree<StatementLabel>> children = this.rep.newSequenceOfTree();
        StatementLabel label = new StatementLabel(Kind.BLOCK);
        this.rep.assemble(label, children);
    }

    /*
     * Standard methods -------------------------------------------------------
     */

    @Override
    public final Statement2 newInstance() {
        try {
            return this.getClass().getConstructor().newInstance();
        } catch (ReflectiveOperationException e) {
            throw new AssertionError(
                    "Cannot construct object of type " + this.getClass());
        }
    }

    @Override
    public final void clear() {
        this.createNewRep();
    }

    @Override
    public final void transferFrom(Statement source) {
        assert source != null : "Violation of: source is not null";
        assert source != this : "Violation of: source is not this";
        assert source instanceof Statement2 : ""
                + "Violation of: source is of dynamic type Statement2";
        /*
         * This cast cannot fail since the assert above would have stopped
         * execution in that case: source must be of dynamic type Statement2.
         */
        Statement2 localSource = (Statement2) source;
        this.rep = localSource.rep;
        localSource.createNewRep();
    }

    /*
     * Kernel methods ---------------------------------------------------------
     */

      /**
     * Returns the kind of the statement represented by the program.
     * 
     * This method retrieves the kind of the root node of the program's representation tree.
     * 
     * @return the kind of the statement
     */
    @Override
    public final Kind kind() {
        // Initialize the label with BLOCK kind as a default value
        Kind label = Kind.BLOCK;
        // Retrieve the kind of the root node of the representation tree
        label = this.rep.root().kind;
        // Return the kind
        return label;
    }






       /**
     * Adds a statement to the block at the specified position.
     * 
     * This method adds the given statement to the block represented by the program at the specified position.
     * 
     * @param pos the position at which the statement should be added
     * @param s the statement to be added
     * @requires s is not null
     * @requires s is not this program
     * @requires s is an instance of Statement2
     * @requires this program is a BLOCK statement
     * @requires 0 <= pos
     * @requires pos <= lengthOfBlock()
     * @requires s is not a BLOCK statement
     * @ensures the statement is added to the block at the specified position
     */
    @Override
    public final void addToBlock(int pos, Statement s) {
        assert s != null : "Violation of: s is not null";
        assert s != this : "Violation of: s is not this";
        assert s instanceof Statement2 : "Violation of: s is a Statement2";
        assert this.kind() == Kind.BLOCK : ""
                + "Violation of: [this is a BLOCK statement]";
        assert 0 <= pos : "Violation of: 0 <= pos";
        assert pos <= this.lengthOfBlock() : ""
                + "Violation of: pos <= [length of this BLOCK]";
        assert s.kind() != Kind.BLOCK : "Violation of: [s is not a BLOCK statement]";
        
        // Cast s to Statement2
        Statement2 localS = (Statement2) s;
        // Create a new sequence to hold the children of the representation tree
        Sequence<Tree<StatementLabel>> children = this.rep.newSequenceOfTree();
        // Disassemble the current representation tree and get the root node label
        StatementLabel label = this.rep.disassemble(children);
        // Add the representation tree of the statement to the children sequence at the specified position
        children.add(pos, localS.rep);
        // Create a new representation for the statement
        localS.createNewRep();
        // Assemble the representation tree with the updated children sequence
        this.rep.assemble(label, children);
    }


        /**
     * Removes a statement from the block at the specified position.
     * 
     * This method removes the statement from the block represented by the program at the specified position
     * and returns the removed statement.
     * 
     * @param pos the position from which the statement should be removed
     * @return the statement removed from the block
     * @requires 0 <= pos
     * @requires pos < lengthOfBlock()
     * @requires this program is a BLOCK statement
     * @ensures the statement is removed from the block at the specified position
     */
    @Override
    public final Statement removeFromBlock(int pos) {
        assert 0 <= pos : "Violation of: 0 <= pos";
        assert pos < this.lengthOfBlock() : ""
                + "Violation of: pos < [length of this BLOCK]";
        assert this.kind() == Kind.BLOCK : ""
                + "Violation of: [this is a BLOCK statement]";
        
        // Create a new instance of Statement2 (Violation of the kernel purity rule)
        Statement2 s = this.newInstance();
        // Create a new sequence to hold the children of the representation tree
        Sequence<Tree<StatementLabel>> children = this.rep.newSequenceOfTree();
        // Disassemble the current representation tree and get the root node label
        StatementLabel label = this.rep.disassemble(children);
        // Remove the representation tree of the statement from the children sequence at the specified position
        s.rep = children.remove(pos);
        // Assemble the representation tree with the updated children sequence
        this.rep.assemble(label, children);
        // Return the removed statement
        return s;
    }

    @Override
    public final int lengthOfBlock() {
        assert this.kind() == Kind.BLOCK : ""
                + "Violation of: [this is a BLOCK statement]";
        return this.rep.numberOfSubtrees();
    }

        /**
     * Assembles an IF statement with the given condition and block.
     * 
     * This method assembles an IF statement with the given condition and block into the program.
     * 
     * @param c the condition for the IF statement
     * @param s the block of statements for the IF statement
     * @requires c is not null
     * @requires s is not null
     * @requires s is not this program
     * @requires s is an instance of Statement2
     * @requires s is a BLOCK statement
     * @ensures an IF statement is assembled with the given condition and block
     */
    @Override
    public final void assembleIf(Condition c, Statement s) {
        assert c != null : "Violation of: c is not null";
        assert s != null : "Violation of: s is not null";
        assert s != this : "Violation of: s is not this";
        assert s instanceof Statement2 : "Violation of: s is a Statement2";
        assert s.kind() == Kind.BLOCK : ""
                + "Violation of: [s is a BLOCK statement]";
        
        // Cast s to Statement2
        Statement2 localS = (Statement2) s;
        // Create a new label for the IF statement with the given condition
        StatementLabel label = new StatementLabel(Kind.IF, c);
        // Create a new sequence to hold the children of the representation tree
        Sequence<Tree<StatementLabel>> children = this.rep.newSequenceOfTree();
        // Add the representation tree of the block to the children sequence
        children.add(0, localS.rep);
        // Assemble the representation tree with the new IF statement label and children sequence
        this.rep.assemble(label, children);
        // Create a new representation for the block statement
        localS.createNewRep(); // clears s
    }


        /**
     * Disassembles an IF statement and returns its condition.
     * 
     * This method disassembles the IF statement represented by the program, retrieves its condition,
     * removes the block of statements from the IF statement, and returns the condition.
     * 
     * @param s the block of statements belonging to the IF statement
     * @return the condition of the IF statement
     * @requires s is not null
     * @requires s is not this program
     * @requires s is an instance of Statement2
     * @requires this program is an IF statement
     * @ensures the IF statement is disassembled and its condition is returned
     */
    @Override
    public final Condition disassembleIf(Statement s) {
        assert s != null : "Violation of: s is not null";
        assert s != this : "Violation of: s is not this";
        assert s instanceof Statement2 : "Violation of: s is a Statement2";
        assert this.kind() == Kind.IF : ""
                + "Violation of: [this is an IF statement]";
        
        // Cast s to Statement2
        Statement2 localS = (Statement2) s;
        // Create a new sequence to hold the children of the representation tree
        Sequence<Tree<StatementLabel>> children = this.rep.newSequenceOfTree();
        // Disassemble the representation tree and retrieve the label of the IF statement
        StatementLabel label = this.rep.disassemble(children);
        // Remove the representation tree of the block from the children sequence
        localS.rep = children.remove(0);
        // Create a new representation for the IF statement
        this.createNewRep(); // clears this
        // Return the condition of the IF statement
        return label.condition;
    }


        /**
     * Assembles an IF-ELSE statement with the given condition and blocks.
     * 
     * This method assembles an IF-ELSE statement with the given condition, primary block (s1),
     * and secondary block (s2) into the program.
     * 
     * @param c the condition for the IF statement
     * @param s1 the primary block of statements for the IF statement
     * @param s2 the secondary block of statements for the ELSE statement
     * @requires c is not null
     * @requires s1 is not null
     * @requires s2 is not null
     * @requires s1 is not this program
     * @requires s2 is not this program
     * @requires s1 is not equal to s2
     * @requires s1 is an instance of Statement2
     * @requires s2 is an instance of Statement2
     * @requires s1 is a BLOCK statement
     * @requires s2 is a BLOCK statement
     * @ensures an IF-ELSE statement is assembled with the given condition and blocks
     */
    @Override
    public final void assembleIfElse(Condition c, Statement s1, Statement s2) {
        assert c != null : "Violation of: c is not null";
        assert s1 != null : "Violation of: s1 is not null";
        assert s2 != null : "Violation of: s2 is not null";
        assert s1 != this : "Violation of: s1 is not this";
        assert s2 != this : "Violation of: s2 is not this";
        assert s1 != s2 : "Violation of: s1 is not s2";
        assert s1 instanceof Statement2 : "Violation of: s1 is a Statement2";
        assert s2 instanceof Statement2 : "Violation of: s2 is a Statement2";
        assert s1.kind() == Kind.BLOCK : "Violation of: [s1 is a BLOCK statement]";
        assert s2.kind() == Kind.BLOCK : "Violation of: [s2 is a BLOCK statement]";

        // Cast s1 and s2 to Statement2
        Statement2 localS1 = (Statement2) s1;
        Statement2 localS2 = (Statement2) s2;
        // Create a new label for the IF-ELSE statement with the given condition
        StatementLabel label = new StatementLabel(Kind.IF_ELSE, c);
        // Create a new sequence to hold the children of the representation tree
        Sequence<Tree<StatementLabel>> children = this.rep.newSequenceOfTree();
        // Add the representation trees of the primary and secondary blocks to the children sequence
        children.add(0, localS1.rep);
        children.add(1, localS2.rep);
        // Assemble the representation tree with the new IF-ELSE statement label and children sequence
        this.rep.assemble(label, children);
        // Create new representations for the primary and secondary blocks
        localS1.createNewRep(); // clears s1
        localS2.createNewRep(); // clears s2
    }


       /**
     * Disassembles an IF-ELSE statement and returns its condition.
     * 
     * This method disassembles the IF-ELSE statement represented by the program, retrieves its condition,
     * removes the primary and secondary blocks of statements from the IF-ELSE statement, and returns the condition.
     * 
     * @param s1 the primary block of statements belonging to the IF-ELSE statement
     * @param s2 the secondary block of statements belonging to the IF-ELSE statement
     * @return the condition of the IF-ELSE statement
     * @requires s1 is not null
     * @requires s2 is not null
     * @requires s1 is not this program
     * @requires s2 is not this program
     * @requires s1 is not equal to s2
     * @requires s1 is an instance of Statement2
     * @requires s2 is an instance of Statement2
     * @requires this program is an IF_ELSE statement
     * @ensures the IF-ELSE statement is disassembled and its condition is returned
     */
    @Override
    public final Condition disassembleIfElse(Statement s1, Statement s2) {
        assert s1 != null : "Violation of: s1 is not null";
        assert s2 != null : "Violation of: s1 is not null";
        assert s1 != this : "Violation of: s1 is not this";
        assert s2 != this : "Violation of: s2 is not this";
        assert s1 != s2 : "Violation of: s1 is not s2";
        assert s1 instanceof Statement2 : "Violation of: s1 is a Statement2";
        assert s2 instanceof Statement2 : "Violation of: s2 is a Statement2";
        assert this.kind() == Kind.IF_ELSE : ""
                + "Violation of: [this is an IF_ELSE statement]";

        // Cast s1 and s2 to Statement2
        Statement2 localS1 = (Statement2) s1;
        Statement2 localS2 = (Statement2) s2;
        // Create a new sequence to hold the children of the representation tree
        Sequence<Tree<StatementLabel>> children = this.rep.newSequenceOfTree();
        // Disassemble the representation tree and retrieve the label of the IF-ELSE statement
        StatementLabel label = this.rep.disassemble(children);
        // Remove the representation trees of the primary and secondary blocks from the children sequence
        localS1.rep = children.remove(0);
        localS2.rep = children.remove(0);
        // Create a new representation for the IF-ELSE statement
        this.createNewRep(); // clears this
        // Return the condition of the IF-ELSE statement
        return label.condition;
    }


       /**
     * Assembles a WHILE statement with the given condition and block.
     * 
     * This method assembles a WHILE statement with the given condition and block into the program.
     * 
     * @param c the condition for the WHILE statement
     * @param s the block of statements for the WHILE statement
     * @requires c is not null
     * @requires s is not null
     * @requires s is not this program
     * @requires s is an instance of Statement2
     * @requires s is a BLOCK statement
     * @ensures a WHILE statement is assembled with the given condition and block
     */
    @Override
    public final void assembleWhile(Condition c, Statement s) {
        assert c != null : "Violation of: c is not null";
        assert s != null : "Violation of: s is not null";
        assert s != this : "Violation of: s is not this";
        assert s instanceof Statement2 : "Violation of: s is a Statement2";
        assert s.kind() == Kind.BLOCK : "Violation of: [s is a BLOCK statement]";

        // Cast s to Statement2
        Statement2 localS = (Statement2) s;
        // Create a new label for the WHILE statement with the given condition
        StatementLabel label = new StatementLabel(Kind.WHILE, c);
        // Create a new sequence to hold the children of the representation tree
        Sequence<Tree<StatementLabel>> children = this.rep.newSequenceOfTree();
        // Add the representation tree of the block to the children sequence
        children.add(0, localS.rep);
        // Assemble the representation tree with the new WHILE statement label and children sequence
        this.rep.assemble(label, children);
        // Create a new representation for the block statement
        localS.createNewRep(); // clears s
    }

    /**
     * Disassembles a WHILE statement and returns its condition.
     * 
     * This method disassembles the WHILE statement represented by the program, retrieves its condition,
     * removes the block of statements from the WHILE statement, and returns the condition.
     * 
     * @param s the block of statements belonging to the WHILE statement
     * @return the condition of the WHILE statement
     * @requires s is not null
     * @requires s is not this program
     * @requires s is an instance of Statement2
     * @requires this program is a WHILE statement
     * @ensures the WHILE statement is disassembled and its condition is returned
     */
    @Override
    public final Condition disassembleWhile(Statement s) {
        assert s != null : "Violation of: s is not null";
        assert s != this : "Violation of: s is not this";
        assert s instanceof Statement2 : "Violation of: s is a Statement2";
        assert this.kind() == Kind.WHILE : ""
                + "Violation of: [this is a WHILE statement]";

        // Cast s to Statement2
        Statement2 localS = (Statement2) s;
        // Create a new sequence to hold the children of the representation tree
        Sequence<Tree<StatementLabel>> children = this.rep.newSequenceOfTree();
        // Disassemble the representation tree and retrieve the label of the WHILE statement
        StatementLabel label = this.rep.disassemble(children);
        // Remove the representation tree of the block from the children sequence
        localS.rep = children.remove(0);
        // Create a new representation for the WHILE statement
        this.createNewRep(); // clears this
        // Return the condition of the WHILE statement
        return label.condition;
    }

    @Override
    public final void assembleCall(String inst) {
        assert inst != null : "Violation of: inst is not null";
        assert Tokenizer.isIdentifier(inst) : ""
                + "Violation of: inst is a valid IDENTIFIER";

        StatementLabel label = new StatementLabel(Kind.CALL, inst);
        Sequence<Tree<StatementLabel>> children = this.rep.newSequenceOfTree();
        this.rep.assemble(label, children);

    }

    @Override
    public final String disassembleCall() {
        assert this.kind() == Kind.CALL : ""
                + "Violation of: [this is a CALL statement]";
        Sequence<Tree<StatementLabel>> children = this.rep.newSequenceOfTree();
        StatementLabel label = this.rep.disassemble(children);
        this.createNewRep();
        return label.instruction;
    }

}
