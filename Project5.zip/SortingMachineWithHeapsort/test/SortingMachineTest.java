import static org.junit.Assert.assertEquals;

import java.util.Comparator;

import org.junit.Test;

import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.sortingmachine.SortingMachine;

/**
 * JUnit test fixture for {@code SortingMachine<String>}'s constructor and
 * kernel methods.
 *
 * @author Xinwei Zhang and Hanqin Zhang
 */
public abstract class SortingMachineTest {

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * implementation under test and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorTest = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorTest(
            Comparator<String> order);

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * reference implementation and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorRef = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorRef(
            Comparator<String> order);

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the
     * implementation under test type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsTest = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsTest(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorTest(order);
        for (int i = 0; i < args.length; i++) {
            SimpleWriter out = new SimpleWriter1L();
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the reference
     * implementation type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsRef = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsRef(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorRef(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     * Comparator<String> implementation to be used in all test cases. Compare
     * {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {

        @Override
        public int compare(String s1, String s2) {
            return s1.compareToIgnoreCase(s2);
        }

    }

    /**
     * Comparator instance to be used in all test cases.
     */
    private static final StringLT ORDER = new StringLT();

    /*
     * Test default Constructor
     */

    @Test
    public final void testdefaultConstructor() {
        SortingMachine<String> m = this.constructorTest(ORDER);
        SortingMachine<String> mExpected = this.constructorRef(ORDER);
        assertEquals(mExpected, m);
    }
    /*
     * Test cases for isInInsertionMode
     */

    @Test
    public final void testisInInsertionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        assertEquals(true, m.isInInsertionMode());
    }
    /*
     * Test cases for isInInsertionMode
     */

    @Test
    public final void testisInInsertionMode2() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);
        assertEquals(mExpected.isInInsertionMode(), m.isInInsertionMode());
    }

    /*
     * Test cases for changeToExtractionMode
     */

    @Test
    public final void testchangeToExtractionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        m.changeToExtractionMode();
        assertEquals(false, m.isInInsertionMode());
    }

    @Test
    public final void testchangeToExtractionMode2() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);
        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();
        assertEquals(mExpected.isInInsertionMode(), m.isInInsertionMode());
    }

    /*
     * Test cases for order
     */

    @Test
    public final void testorder() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        assertEquals(ORDER, m.order());
    }

    /*
     * Test cases for order
     */

    @Test
    public final void testorder2() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);
        assertEquals(mExpected.order(), m.order());
    }

    /*
     * Test cases for Add
     */

    @Test
    public final void Addwithnonelements() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsTest(ORDER, true,
                "4");
        m.add("4");
        assertEquals(mExpected, m);
    }

    /*
     * Test cases for Add
     */
    @Test
    public final void Addwith1elements() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1");
        SortingMachine<String> mExpected = this.createFromArgsTest(ORDER, true,
                "1", "4");
        m.add("4");
        assertEquals(mExpected, m);
    }

    /*
     * Test cases for Add
     */
    @Test
    public final void Addwith2elements() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1",
                "2");
        SortingMachine<String> mExpected = this.createFromArgsTest(ORDER, true,
                "1", "2", "4");
        m.add("4");
        assertEquals(mExpected, m);
    }

    /*
     * Test cases for Add
     */
    @Test
    public final void Addwith3elements() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1",
                "2", "3");
        SortingMachine<String> mExpected = this.createFromArgsTest(ORDER, true,
                "1", "2", "3", "4");
        m.add("4");
        assertEquals(mExpected, m);
    }

    /*
     * Test cases for size
     */

    @Test
    public final void sizewithnonelements() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);
        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();
        assertEquals(mExpected.size(), m.size());
    }

    /*
     * Test cases for size
     *
     */
    @Test
    public final void sizewith1elements() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1");
        m.changeToExtractionMode();
        assertEquals(1, m.size());
    }

    /*
     * Test cases for size
     */

    @Test
    public final void sizewith2elements() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1",
                "2");
        m.changeToExtractionMode();
        assertEquals(2, m.size());
    }

    /*
     * Test cases for size
     */

    @Test
    public final void sizewith3elements() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1",
                "2", "3");
        m.changeToExtractionMode();
        assertEquals(3, m.size());
    }

    /*
     * Test cases for removeFirst
     */

    @Test
    public final void removewith3elements() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "1",
                "2", "3");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "1", "2", "3");
        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();
        assertEquals(mExpected.removeFirst(), m.removeFirst());
    }

    /*
     * Test cases for removeFirst
     */

    @Test
    public final void removewith4elements() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "4",
                "3", "red", "2");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "4", "3", "red", "2");
        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();
        assertEquals(mExpected.removeFirst(), m.removeFirst());
    }

    /*
     * Test cases for removeFirst
     */

    @Test
    public final void removewithMultielements() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "red",
                "blue", "1", "2", "a", "d", "you", "me", "who");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "red", "blue", "1", "2", "a", "d", "you", "me", "who");
        m.changeToExtractionMode();
        mExpected.changeToExtractionMode();
        assertEquals(mExpected.removeFirst(), m.removeFirst());
    }

}
