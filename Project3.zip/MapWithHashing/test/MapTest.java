import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.map.Map;

/**
 * JUnit test fixture for {@code Map<String, String>}'s constructor and kernel
 * methods.
 *
 * @author Xinwei Zhang and Hanqin Zhang
 *
 */
public abstract class MapTest {

    /**
     * Invokes the appropriate {@code Map} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new map
     * @ensures constructorTest = {}
     */
    protected abstract Map<String, String> constructorTest();

    /**
     * Invokes the appropriate {@code Map} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new map
     * @ensures constructorRef = {}
     */
    protected abstract Map<String, String> constructorRef();

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the implementation
     * under test type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsTest = [pairs in args]
     */
    private Map<String, String> createFromArgsTest(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorTest();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the reference
     * implementation type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsRef = [pairs in args]
     */
    private Map<String, String> createFromArgsRef(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorRef();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    @Test
    public final void testConstructor() {
        Map<String, String> s = this.constructorTest();
        Map<String, String> sExpected = this.constructorRef();
        assertEquals(s, sExpected);

    }

    @Test
    public final void testArgsConstructorEmpty() {
        Map<String, String> s = this.createFromArgsTest();
        Map<String, String> sExpected = this.createFromArgsRef();
        assertEquals(s, sExpected);

    }

    @Test
    public final void testArgsConstructor() {
        Map<String, String> s = this.createFromArgsTest("a", "b");
        Map<String, String> sExpected = this.createFromArgsRef("a", "b");
        assertEquals(s, sExpected);

    }

    /**
     * Test for Empty add
     */
    @Test
    public final void testAddtoEmptyMap() {
        Map<String, String> s = this.createFromArgsTest();
        Map<String, String> sExpected = this.createFromArgsRef("1", "2");
        s.add("1", "2");
        assertEquals(s, sExpected);

    }

    /**
     * Test for Empty add
     */
    @Test
    public final void testAddtoMapWithOnekey() {
        Map<String, String> s = this.createFromArgsTest("1", "2");
        Map<String, String> sExpected = this.createFromArgsRef("1", "2", "3",
                "4");
        s.add("3", "4");
        assertEquals(s, sExpected);

    }

    /**
     * Test for Empty add
     */
    @Test
    public final void testAddtoMapWithTwokey() {
        Map<String, String> s = this.createFromArgsTest("1", "2", "a", "b");
        Map<String, String> sExpected = this.createFromArgsRef("1", "2", "a",
                "b", "5", "6");
        s.add("5", "6");
        assertEquals(s, sExpected);

    }

    /**
     * Test for Empty add
     */
    @Test
    public final void testAddtoMapWithThreekey() {
        Map<String, String> s = this.createFromArgsTest("1", "2", "3", "a", "b",
                "6");
        Map<String, String> sExpected = this.createFromArgsRef("1", "2", "3",
                "a", "b", "6", "7", "8");
        s.add("7", "8");
        assertEquals(s, sExpected);

    }

    /**
     * Test for Empty add
     */
    @Test
    public final void testAddtoMapWithThreekeyTwice() {
        Map<String, String> s = this.createFromArgsTest("1", "2", "3", "a", "b",
                "6");
        Map<String, String> sExpected = this.createFromArgsRef("1", "2", "3",
                "a", "b", "6", "7", "8", "9", "0");
        s.add("7", "8");
        s.add("9", "0");
        assertEquals(s, sExpected);

    }

    /**
     * Test for Remove.
     */
    @Test
    public final void testRemoveMapWithOnekey() {
        Map<String, String> s = this.createFromArgsTest("1", "2");
        Map<String, String> sExpected = this.createFromArgsRef();

        s.remove("1");
        assertEquals(s, sExpected);

    }

    /**
     * Test for Remove.
     */
    @Test
    public final void testRemoveMapWithTwokey() {
        Map<String, String> s = this.createFromArgsTest("1", "2", "a", "b");
        Map<String, String> sExpected = this.createFromArgsRef("a", "b");
        s.remove("1");
        assertEquals(s, sExpected);

    }

    /**
     * Test for Remove.
     */
    @Test
    public final void testRemoveMapWithThreekey() {
        Map<String, String> s = this.createFromArgsTest("1", "2", "a", "b", "5",
                "6");
        Map<String, String> sExpected = this.createFromArgsRef("1", "2", "5",
                "6");
        s.remove("a");
        assertEquals(s, sExpected);

    }

    /**
     * Test for Remove.
     */
    @Test
    public final void testRemoveMapWithTwokeytwice() {
        Map<String, String> s = this.createFromArgsTest("1", "2", "a", "b");
        Map<String, String> sExpected = this.createFromArgsRef();
        s.remove("a");
        s.remove("1");
        assertEquals(s, sExpected);

    }

    /**
     * Test for Remove.
     */
    @Test
    public final void testRemoveMapWithThreekeytwice() {
        Map<String, String> s = this.createFromArgsTest("1", "2", "a", "b", "5",
                "6");
        Map<String, String> sExpected = this.createFromArgsRef("1", "2");
        s.remove("a");
        s.remove("5");
        assertEquals(s, sExpected);

    }

    /**
     * Test for RemoveAny.
     */
    @Test
    public final void testRemoveAnyMapWithOnekey() {
        Map<String, String> s = this.createFromArgsTest("1", "2");
        int len = s.size();
        s.removeAny();
        int Len = s.size();
        assertEquals(len - 1, Len);

    }

    /**
     * Test for RemoveAny.
     */
    @Test
    public final void testRemoveAnyMapWithTwokey() {
        Map<String, String> s = this.createFromArgsTest("1", "2", "3", "4");
        int len = s.size();
        s.removeAny();
        int Len = s.size();
        assertEquals(len - 1, Len);

    }

    /**
     * Test for RemoveAny.
     */
    @Test
    public final void testRemoveAnyMapWithThreekey() {
        Map<String, String> s = this.createFromArgsTest("1", "2", "3", "4", "5",
                "6");
        int len = s.size();
        s.removeAny();
        int Len = s.size();
        assertEquals(len - 1, Len);

    }

    /**
     * Test for Value.
     */
    @Test
    public final void testValueMapWithOnekey() {
        Map<String, String> s = this.createFromArgsTest("1", "2");
        String s1 = s.value("1");
        assertEquals(s1, "2");
    }

    /**
     * Test for Value.
     */
    @Test
    public final void testValueMapWithTwokey() {
        Map<String, String> s = this.createFromArgsTest("1", "2", "abc", "def");
        String s1 = s.value("abc");
        String s2 = s.value("1");
        assertEquals(s1, "def");
        assertEquals(s2, "2");
    }

    /**
     * Test for Value for Map With Three key
     */
    @Test
    public final void testValueMapWithThreekey() {
        Map<String, String> s = this.createFromArgsTest("1", "2", "abc", "def",
                "789", "789");
        String s1 = s.value("789");
        String s2 = s.value("1");
        String s3 = s.value("abc");
        assertEquals(s1, "789");
        assertEquals(s2, "2");
        assertEquals(s3, "def");
    }

    /**
     *
     * Test for Has-key.
     */
    @Test
    public final void testHasKeyMapWithOnekey() {
        Map<String, String> s = this.createFromArgsTest("1", "2");
        assertEquals(s.hasKey("1"), true);
        assertEquals(s.hasKey("2"), false);
    }

    /**
     *
     * Test for Has-key.
     */
    @Test
    public final void testHasKeyMapWithTwokey() {
        Map<String, String> s = this.createFromArgsTest("1", "2", "abc", "def");
        assertEquals(s.hasKey("1"), true);
        assertEquals(s.hasKey("abc"), true);
        assertEquals(s.hasKey("def"), false);
        assertEquals(s.hasKey("you"), false);
    }

    /**
     *
     * Test for Has-key.
     */
    @Test
    public final void testHasKeyMapWithThreekey() {
        Map<String, String> s = this.createFromArgsTest("1", "2", "abc", "def",
                "4", "5");
        assertEquals(s.hasKey("1"), true);
        assertEquals(s.hasKey("abc"), true);
        assertEquals(s.hasKey("4"), true);
        assertEquals(s.hasKey("def"), false);
        assertEquals(s.hasKey("you"), false);
    }

    /**
     *
     * Test for Has-key.
     */
    @Test
    public final void testHasKeyFalse() {
        Map<String, String> s = this.createFromArgsTest("1", "2", "3", "4");
        assertEquals(s.hasKey("5"), false);
    }

    /**
     * Test for Size.
     */
    @Test
    public final void testEmptySize() {
        Map<String, String> s = this.createFromArgsTest();
        Map<String, String> sExpected = this.createFromArgsTest();
        assertEquals(s.size(), sExpected.size());
    }

    /**
     * Test for Size.
     */
    @Test
    public final void testEmptySizeMapWithOnekey() {
        Map<String, String> s = this.createFromArgsTest("1", "2");
        Map<String, String> sExpected = this.createFromArgsTest("1", "2");
        assertEquals(s.size(), sExpected.size());
    }

    /**
     * Test for Size
     */
    @Test
    public final void testEmptySizeMapWithMultkey() {
        Map<String, String> s = this.createFromArgsTest("1", "2", "a", "b", "c",
                "d");
        Map<String, String> sExpected = this.createFromArgsTest("1", "2", "a",
                "b", "c", "d");
        assertEquals(s.size(), sExpected.size());
    }
}
